"use strict";

window.dceJsField = {
	refresherGenerators: {}
};

dceJsField.registerRefresherGenerator = function(field_id, refresherGenerator) {
	this.refresherGenerators[field_id] = refresherGenerator;
}

let getFieldValue = (form, id) => {
	let data = new FormData(form);
	if (data.has(`form_fields[${id}]`)) {
		return data.get(`form_fields[${id}]`);
	} else if (data.has`form_fields[$id][]`)  {
		return data.getAll(key);
	}
	return "";
}

let makeGetFieldFunction = (form) => {
	return (id, toFloat=false) => {
		let val = getFieldValue(form, id);
		return toFloat ? parseFloat(val) : val;
	}
}

function initializeJsField(wrapper, widget) {
	let input = wrapper.getElementsByTagName('input')[0];
	let form = widget.getElementsByTagName('form')[0];
	let fieldId = input.dataset.fieldId;
	let realTime = input.dataset.realTime === 'yes';
	if (input.dataset.hide == 'yes') {
		wrapper.style.display = "none";
	}
	let refresherGenerator = dceJsField.refresherGenerators[fieldId];
	// if the user code has a syntax error the registration will have failed and
	// we won't find the field:
	if (! refresherGenerator) {
		input.value = jsFieldLocale.syntaxError;
		return;
	}
	let refresher = refresherGenerator(makeGetFieldFunction(form));
	if (typeof refresher !== "function") {
		input.value = jsFieldLocale.returnError;
		return;
	}
	let onChange = () => {
		input.value = refresher();
	}
	onChange();
	form.addEventListener(realTime ? 'input' : 'change', onChange);

}

function initializeAllJsFieldFields($scope) {
	$scope.find('.elementor-field-type-dce_js_field').each((_, w) => initializeJsField(w, $scope[0]));
}

jQuery(window).on('elementor/frontend/init', function() {
	elementorFrontend.hooks.addAction('frontend/element_ready/form.default', initializeAllJsFieldFields);
});
